﻿namespace CaliburnAppWP7.ViewModels
{
    using Caliburn.Micro;

    public class MainViewModel : Conductor<IScreen>.Collection.OneActive
    {
    }
}
