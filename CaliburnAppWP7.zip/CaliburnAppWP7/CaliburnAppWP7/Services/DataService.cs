﻿namespace CaliburnAppWP7.Services
{
    public class DataService
    {
    }
}
